export interface Feedback {
  id: string;
  storeId: string;
  customerId: string;
  rating: number;
  comment: string;
  categoryId: string;
  createdAt: string;
}

export interface FeedbackCreateDto {
  storeId: string;
  customerId: string;
  rating: number;
  comment: string;
  categoryId: string;
}