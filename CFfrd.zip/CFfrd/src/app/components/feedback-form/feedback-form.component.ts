// // import { Component } from '@angular/core';

// // @Component({
// //   selector: 'app-feedback-form',
// //   imports: [],
// //   templateUrl: './feedback-form.component.html',
// //   styleUrl: './feedback-form.component.css'
// // })
// // export class FeedbackFormComponent {

// // }


// import { Component } from '@angular/core';
// import { CommonModule } from '@angular/common';

// import {
//   FormBuilder,
//   ReactiveFormsModule,
//   Validators
// } from '@angular/forms';

// import { FeedbackService } from '../../services/feedback.service';

// import { FeedbackCreateDto } from '../../models/feedback.model';

// @Component({
//   selector: 'app-feedback-form',
//   standalone: true,
//   imports: [
//     ReactiveFormsModule,
//     CommonModule
//   ],
//   templateUrl: './feedback-form.component.html',
//   styleUrl: './feedback-form.component.css'
// })
// export class FeedbackFormComponent {

//   constructor(
//     private formBuilder: FormBuilder,
//     private feedbackService: FeedbackService
//   ) {}

//   feedbackForm =
//     this.formBuilder.group({

//       storeId: [
//         '',
//         [Validators.required]
//       ],

//       customerId: [
//         '',
//         [Validators.required]
//       ],

//       rating: [
//         5,
//         [
//           Validators.required,
//           Validators.min(1),
//           Validators.max(5)
//         ]
//       ],

//       comment: [
//         '',
//         [Validators.required]
//       ],

//       categoryId: [
//         '',
//         [Validators.required]
//       ]

//     });

//   submit(): void {

//     if (this.feedbackForm.invalid) {

//       this.feedbackForm.markAllAsTouched();

//       return;

//     }

//     const feedback: FeedbackCreateDto = {

//       storeId:
//         this.feedbackForm.value.storeId!,

//       customerId:
//         this.feedbackForm.value.customerId!,

//       rating:
//         Number(this.feedbackForm.value.rating),

//       comment:
//         this.feedbackForm.value.comment!,

//       categoryId:
//         this.feedbackForm.value.categoryId!

//     };

//     this.feedbackService
//       .createFeedback(feedback)
//       .subscribe({

//         next: () => {

//           alert(
//             'Feedback created successfully.'
//           );

//           this.feedbackForm.reset({
//             rating: 5
//           });

//         },

//         error: (error) => {

//           console.error(error);

//           alert(
//             'Unable to create feedback.'
//           );

//         }

//       });
//   }
// }



import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';

import { FeedbackService } from '../../services/feedback.service';
import { FeedbackCreateDto } from '../../models/feedback.model';

@Component({
  selector: 'app-feedback-form',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  templateUrl: './feedback-form.component.html',
  styleUrl: './feedback-form.component.css'
})
export class FeedbackFormComponent {

  feedbackForm: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private feedbackService: FeedbackService
  ) {
    this.feedbackForm = this.formBuilder.group({

      storeId: [
        '',
        Validators.required
      ],

      customerId: [
        '',
        Validators.required
      ],

      rating: [
        5,
        [
          Validators.required,
          Validators.min(1),
          Validators.max(5)
        ]
      ],

      comment: [
        '',
        Validators.required
      ],

      categoryId: [
        '',
        Validators.required
      ]

    });
  }

  submit(): void {

    if (this.feedbackForm.invalid) {

      this.feedbackForm.markAllAsTouched();

      return;

    }

    const feedback: FeedbackCreateDto = {

      storeId:
        this.feedbackForm.value.storeId,

      customerId:
        this.feedbackForm.value.customerId,

      rating:
        Number(this.feedbackForm.value.rating),

      comment:
        this.feedbackForm.value.comment,

      categoryId:
        this.feedbackForm.value.categoryId

    };

    this.feedbackService
      .createFeedback(feedback)
      .subscribe({

        next: () => {

          alert('Feedback created successfully.');

          this.feedbackForm.reset({
            rating: 5
          });

        },

        error: (error) => {

          console.error(error);

          alert('Unable to create feedback.');

        }

      });
  }
}