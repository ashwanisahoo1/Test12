// import { Component, OnInit } from '@angular/core';
// import { CommonModule } from '@angular/common';

// import { Feedback } from '../../models/feedback.model';
// import { FeedbackService } from '../../services/feedback.service';

// @Component({
//   selector: 'app-feedback-list',
//   standalone: true,
//   imports: [CommonModule],
//   templateUrl: './feedback-list.component.html',
//   styleUrl: './feedback-list.component.css'
// })
// export class FeedbackListComponent {

// }

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Feedback } from '../../models/feedback.model';
import { FeedbackService } from '../../services/feedback.service';

@Component({
  selector: 'app-feedback-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './feedback-list.component.html',
  styleUrl: './feedback-list.component.css'
})
export class FeedbackListComponent implements OnInit {

  feedbacks: Feedback[] = [];

  loading = false;

  errorMessage = '';

  constructor(
    private feedbackService: FeedbackService
  ) {}

  ngOnInit(): void {
    this.loadFeedbacks();
  }

  loadFeedbacks(): void {

    this.loading = true;

    this.errorMessage = '';

    this.feedbackService
      .getFeedbacks()
      .subscribe({

        next: (data) => {

          this.feedbacks = data;

          this.loading = false;

        },

        error: (error) => {

          console.error(error);

          this.errorMessage =
            'Unable to load feedback data.';

          this.loading = false;

        }

      });
  }

  deleteFeedback(id: string): void {

    const confirmed = confirm(
      'Are you sure you want to delete this feedback?'
    );

    if (!confirmed) {
      return;
    }

    this.feedbackService
      .deleteFeedback(id)
      .subscribe({

        next: () => {

          alert('Feedback deleted successfully.');

          this.loadFeedbacks();

        },

        error: (error) => {

          console.error(error);

          alert('Unable to delete feedback.');

        }

      });
  }
}
