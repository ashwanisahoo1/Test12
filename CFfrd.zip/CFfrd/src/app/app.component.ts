// import { Component } from '@angular/core';
// import { RouterOutlet } from '@angular/router';

// @Component({
//   selector: 'app-root',
//   imports: [RouterOutlet],
//   templateUrl: './app.component.html',
//   styleUrl: './app.component.css'
// })
// export class AppComponent {
//   title = 'CustomerFeedbackUI';
// }


import { Component } from '@angular/core';

import { FeedbackFormComponent }
  from './components/feedback-form/feedback-form.component';

import { FeedbackListComponent }
  from './components/feedback-list/feedback-list.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    FeedbackFormComponent,
    FeedbackListComponent
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {

  title = 'Customer Feedback System';

}