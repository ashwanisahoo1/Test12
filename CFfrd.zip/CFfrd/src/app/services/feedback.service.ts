import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Feedback,FeedbackCreateDto } from '../models/feedback.model';

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {


  private readonly apiUrl =
  'https://localhost:7239/api/Feedbacks';
   // 'https://localhost:5001/api/Feedbacks';
  constructor(private http: HttpClient) { }

// GET: api/Feedbacks
  getFeedbacks(
    page: number = 1,
    pageSize: number = 20
  ): Observable<Feedback[]> {

    return this.http.get<Feedback[]>(
      `${this.apiUrl}?page=${page}&pageSize=${pageSize}`
    );
  }

  // GET: api/Feedbacks/{id}
  getFeedbackById(
    id: string
  ): Observable<Feedback> {

    return this.http.get<Feedback>(
      `${this.apiUrl}/${id}`
    );
  }

  // POST: api/Feedbacks
  createFeedback(
    feedback: FeedbackCreateDto
  ): Observable<Feedback> {

    return this.http.post<Feedback>(
      this.apiUrl,
      feedback
    );
  }

  // PUT: api/Feedbacks/{id}
  updateFeedback(
    id: string,
    feedback: FeedbackCreateDto
  ): Observable<void> {

    return this.http.put<void>(
      `${this.apiUrl}/${id}`,
      feedback
    );
  }

  // DELETE: api/Feedbacks/{id}
  deleteFeedback(
    id: string
  ): Observable<void> {

    return this.http.delete<void>(
      `${this.apiUrl}/${id}`
    );
  }

}
