﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using WebAPI.Models;
using WebAPI.ViewModels;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthAPIController : ControllerBase
    {
        static List<User> users = new List<User>()
        {
            new User(){ UserId = 1, Name = "Admin", EmailId = "admin@gemail.com", Password = "123", PhoneNumber = "100001", Role = "Admin"}
        };

        [HttpPost]
        [Route("validate/{token}")]
        public IActionResult Authenticate(string token)
        {
            if (token == "123")
                return Ok(true);
            else
                return StatusCode(StatusCodes.Status401Unauthorized, false);
        }

        [HttpPost]
        [Route("create")]
        public IActionResult CreateUser(User user)
        {
            if(ModelState.IsValid)
            {
                user.Role = "Customer";
                users.Add(user);
                return StatusCode(StatusCodes.Status201Created, true);
            }
            return StatusCode(StatusCodes.Status400BadRequest, false);
        }

        [HttpPost]
        [Route("validate")]
        public IActionResult ValidateUser(LoginViewModel login)
        {
            var userObj = users.Where(s => s.EmailId.ToLower() == login.EmailId.ToLower()
                                && s.Password == login.Password).FirstOrDefault();
            if(userObj != null)
            {
                string token = GenerateToken(userObj);
                var data = new { Token = token, Name = userObj.Name, Role = userObj.Role };
                return StatusCode(StatusCodes.Status200OK, data);
            }
            return StatusCode(StatusCodes.Status401Unauthorized);
        }

        private string GenerateToken(User user)
        {
            var symetrickey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("12345678901234567890"));
            var credential = new SigningCredentials(symetrickey, SecurityAlgorithms.HmacSha256);

            var claims = new Claim[]
            {
                new Claim(ClaimTypes.Name, user.Name),
                new Claim(ClaimTypes.Email, user.EmailId),
                new Claim(ClaimTypes.Role, user.Role)
            };

            var token = new JwtSecurityToken(
                issuer: "www.myapp.com",
                audience: "www.test.com",
                claims: claims,
                expires: DateTime.Now.AddMinutes(20),
                signingCredentials: credential);

            return new JwtSecurityTokenHandler().WriteToken(token);

        }
    }
}
