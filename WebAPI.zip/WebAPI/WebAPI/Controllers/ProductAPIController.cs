﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebAPI.Models;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class ProductAPIController : ControllerBase
    {
        static List<Product> products = new List<Product>()
        {
            new Product() {ProductId = 101, ProductCode = "P001", ProductName = "Laptop", Price = 50000 }
            , new Product() {ProductId = 102, ProductCode = "P002", ProductName = "Router", Price = 5000 }
        };

        [Route("getall")]
        [HttpGet]
        public IActionResult GetAllProducts()
        {
            return Ok(products);
        }


        [HttpGet]
        [Route("get/{productid}")]
        public IActionResult GetProductById(int productid)
        {
            var product = (from p in products
                           where p.ProductId == productid
                           select p).FirstOrDefault();

            return StatusCode(200,product);
        }

        [HttpPost]
        [Route("add")]
        public IActionResult AddProduct(Product productToAdd)
        {
            if (ModelState.IsValid)
            {
                products.Add(productToAdd);
                return StatusCode(201, true);
            }
            return StatusCode(201, false);
        }
        
        [HttpDelete]
        [Route("delete/{productid}")]
        public IActionResult DeleteProduct(int productid)
        {
            var productToDelete = (from p in products
                                   where p.ProductId == productid
                                   select p).FirstOrDefault();

            if(productToDelete != null)
            {
                products.Remove(productToDelete);
                return StatusCode(StatusCodes.Status202Accepted, true);
            }
            return StatusCode(StatusCodes.Status404NotFound, false);
        }

        [HttpPut]
        [Route("update")]
        public IActionResult UpdateProduct(Product productToModify)
        {
            //update logic will go here
            return StatusCode(StatusCodes.Status200OK);
        }
    }
}
