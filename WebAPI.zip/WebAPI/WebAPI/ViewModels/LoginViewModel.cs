﻿namespace WebAPI.ViewModels
{
    public class LoginViewModel
    {
        public string EmailId { get; set; }
        public string Password { get; set; }
    }
}
