//top level statements C#10.0

using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddCors(config=>
{
    config.AddPolicy("mypolicy", option =>
    {
        option.AllowAnyMethod(); //allow get,post, put,delete
        option.AllowAnyHeader();
        option.WithOrigins("http://localhost:4200");
    });
});

builder.Services.AddControllers().AddJsonOptions(op=>
{
    op.JsonSerializerOptions.PropertyNamingPolicy = null;
});
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(config=>
{
    config.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters()
    {
        ValidateIssuer = true,
        ValidIssuer = "www.myapp.com",
        ValidateAudience = true,
        ValidAudience = "www.test.com",
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("12345678901234567890"))
    };
});

//----------------------------------------------------------------------
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseCors("mypolicy");

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();

app.Map("/test", async context =>
{
    await context.Response.WriteAsync("test data");
});

app.Run();
